<?php include('site/includes/top.php'); ?>
        <script>
        document.title = "<?php echo $course ?> Assignments";
        </script>
        <div id="contents">
          <h1>Course Assignments</h1>
          <br/>
          <p class="text">Assignments are due at <strong class="bold">11:59pm ET</strong> on the assigned due date. Assignment solutions will be posted on <a href="https://sakailogin.nd.edu/" target="_blank">Sakai</a>.</p>

          <h2>Required Software</h2>
          <p class="text padding-top padding-bottom">Programming assignments will require the use of Python 2.7, as well as additional Python packages. For your convenience, an Ubuntu system has been preconfigured by the <?php echo $instructor ?> with the software required for the assignments.<!--This image file is compatible with most standard virtualization software. Recommended virtualization software includes <a href="https://www.virtualbox.org/" target="_blank">VirtualBox</a> (open-source) and <a href="http://www.vmware.com/products/player/" target="_blank">VMware Player</a> (free for noncommercial personal use).--> A virtual machine snapshot image (VDI) file of the preconfigured system is available <a href="https://notredame.box.com/s/nvx1awtn7sddydw5abs6" target="_blank">here (as a compressed .zip file)</a>. The image file is compatible with <a href="https://www.virtualbox.org/" target="_blank">VirtualBox</a>, a standard, open-source virtualization software package.</p>
          
          <p class="text">The image file is a snapshot (or copy) of an <a href="http://www.ubuntu.com/desktop" target="_blank">Ubuntu 12.04</a> (32-bit) system preconfigured with the following relevant software:</p>
          <ul class="text padding-bottom">
            <li class="item"><a href="http://www.python.org/download/releases/2.7.3/" target="_blank">Python <!--2.7.5-->2.7.3</a></span> (An interactive, object-oriented, extensible programming language.)</li>
            <li class="item"><a href="http://numpy.scipy.org/" target="_blank">NumPy <!--1.7.1-->1.8.0</a></span> (A Python package for scientific computing.)</li>
            <li class="item"><a href="http://www.scipy.org/scipylib" target="_blank">SciPy (library) <!--0.13.0-->0.9.0</a></span> (A Python package for mathematics, science, and engineering.)</li>
            <li class="item"><a href="http://matplotlib.sourceforge.net/" target="_blank">Matplotlib 1.3.1</a></span> (A Python package for 2D plotting.)</li>
            <li class="item"><a href="http://pandas.pydata.org/" target="_blank">pandas 0.12.0</a></span> (A Python package for high-performance, easy-to-use data structures and data analysis tools.)</li>
            <li class="item"><a href="http://ipython.org/" target="_blank">IPython 1.1.0</a></span> (An architecture for interactive computing with Python.)</li>
            <li class="item"><a href="http://scikit-learn.org/" target="_blank">scikit-learn 0.14.1</a></span> (A Python package for machine learning.)</li>
            <li class="item"><a href="http://www.geany.org/" target="_blank">Geany <!--1.23.1-->0.21</a></span> (A text editor.)</li>
          </ul>

          <p class="text padding-bottom">If you experience difficulties in setting up the virtualization software or using the image file, please let the <?php echo $instructor ?> know as soon as possible. While you may, at your own discretion, directly install the relevant software on to your personal machine, all submitted code is expected to function properly on the provided image file. Additionally, the <?php echo $instructor ?> may only provide support for installations via the image file.</p>

          <p class="text">Most of the relevant software is a part of the <a href="http://www.scipy.org/" target="_blank">SciPy stack</a>, a collection of Python-based open source software for mathematics, science, and engineering (which includes Python, NumPy, the SciPy library, Matplotlib, pandas, IPython, and scikit-learn). The <a href="http://www.continuum.io/downloads" target="_blank">Anaconda Python Distribution</a> is a free distribution for the SciPy stack that supports Linux, Mac, and Windows.<!--Anaconda 1.8.0 was used to install the SciPy stack on the provided image file.-->

          <h2>Submission Instructions</h2>
          <p class="text padding-top"><span>To submit your assignment, create a folder named <strong class="bold">netid_assignment#</strong> and place your code files, data files, and any other assignment files in this folder.<!-- Text answers should be in PDF or plain text format.-->  Compress the folder (please use .zip compression) and submit it to your <?php echo $course ?> dropbox folder via <a href="https://webfile.nd.edu/" target="_blank">WebFile</a> or SCP. Your course dropbox folder is located on <a href="http://oithelp.nd.edu/shared-file-space/afs/" target="_blank">the AFS file space</a> at <span class="break-word">&ldquo;<?php echo $course_dir ?>/dropbox/yourNetID&rdquo;</span>. </span><em class="italic">If we cannot access your work because these directions are not followed correctly, we will not grade your work.</em></p>

          <h2 class="text"><a></a><span>Assignments </span></h2>
          <h3 class="text"><a></a><span><a href="content/assignments/assignment0.pdf" target="_blank">Assignment 0</a></span></h3>
          <p class="text"><span>Due date:  Wednesday, January 22</span></p><p class="text"><span>Not graded!</span></p>
          <p class="text"><span><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/assignment0/assignment0_sol.ipynb" target="_blank">Solution</a></span></p>
          <h3 class="text"><a></a><span><a href="content/assignments/assignment1.pdf" target="_blank">Assignment 1</a></span></h3>
          <p class="text"><span>Due date:  Monday, February 10</span></p>
          <p class="text"><span><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/assignment1/assignment1_sol.ipynb" target="_blank">Solution</a></span></p>
          <h3 class="text"><a></a><span><a href="content/assignments/assignment2.pdf" target="_blank">Assignment 2</a></span></h3>
          <p class="text"><span>Due date:  Monday, March 3</span></p><p class="text"><span></span></p>
          <p class="text"><span><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/assignment2/assignment2_sol.ipynb" target="_blank">Solution</a></span></p>
          <h3 class="text"><a></a><span><a href="content/assignments/assignment3.pdf" target="_blank">Assignment 3</a></span></h3>
          <p class="text"><span>Due date:  Friday, April 4</span></p><p class="text"><span><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/assignment3/assignment3_sol.ipynb" target="_blank">Solution</a></span></p>
          <br/>
        </div>
        <div class="clearer"></div>
        <div><center><a href="#" class="topOfPage">Top</a></center></div>
<?php include('site/includes/bottom.php'); ?>
