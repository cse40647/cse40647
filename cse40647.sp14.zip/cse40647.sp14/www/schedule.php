<?php include('site/includes/top.php'); ?>
        <script>
        document.title = "<?php echo $course ?> Schedule";
        </script>
        <div id="contents">
          <h1>Course Schedule</h1>
          <br/>
          <p class="text">The weekly content coverage is subject to change. Lecture slides and IPython notebooks will be posted on this page.</p><br/>

          <span id="key-table-header" class="text-header">Content Key:</span>
          <div class="clearer"></div>
          <div id="key-table">
              <div id="key-row-left">
                <div class="key-color key-topic-1"></div>
                <div class="key-text">Preliminaries</div>
                <div class="key-color key-topic-2"></div>
                <div class="key-text">Data Understanding</div>
               <div class="key-color key-topic-3"></div>
                <div class="key-text">Data Preprocessing</div>
              </div>
              <div id="key-row-right">
                  <div class="key-color key-topic-7"></div>
                  <div class="key-text">Advanced Topics</div>
              </div>
              <div id="key-row-center">
                <div class="key-color key-topic-4"></div>
                <div class="key-text">Clustering &amp; Association</div>
                <div class="key-color key-topic-5"></div>
                <div class="key-text">Classification &amp; Regression</div>
                <div class="key-color key-topic-6"></div>
                <div class="key-text">Validation &amp; Interpretation</div>
              </div>
          </div>
          <div class="clearer"></div>

          <div id="schedule-table">
            <div id="schedule-header">
              <div class="schedule-header-cell">WEEK</div>
              <div class="schedule-header-cell"></div>
              <div class="schedule-header-cell"></div>
              <div class="schedule-header-cell"></div>
              <div class="schedule-header-cell">MONDAY</div>
              <div class="schedule-header-cell">WEDNESDAY</div>
              <div class="schedule-header-cell">FRIDAY</div>
              <div class="schedule-header-cell">MATERIAL</div>
            </div>
            <div class="sep"><hr class="hr-top"></div>
            <div class="sep"><hr class="hr-top"></div>
            <div class="sep"><hr class="hr-top"></div>
            <div class="sep"><hr class="hr-top"></div>
            <div class="sep"><hr class="hr-top"></div>
            <div class="sep"><hr class="hr-top"></div>
            <div class="sep"><hr class="hr-top"></div>
            <div class="sep"><hr class="hr-top"></div>
            <div class="schedule-row">
              <div class="schedule-week">Week&nbsp;1<br/>(1/13&ndash;1/19)</div>
              <div class="schedule-keys key-topic-1"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-day"></div>
              <div class="schedule-day">What is data mining? Why does it matter? <em class="italic">(pp. 1&ndash;11)</em></div>
              <div class="schedule-day">Instances and features. Collaborative filtering (part I).</div>
              <div class="schedule-notes">
                <div class="lecture-notes">
                  <span class="pdficon"><a href="content/lectures/01%20-%20Introduction.pdf" target="_blank"><span>1</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
                  <span class="pdficon"><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/01%20-%20IPython%20Notebook%20Demo.ipynb" target="_blank"><span>1</span><sup><img src="site/images/icons/ipynbicon_small.png"></sup></a></span><br/>
                  
                  <span class="pdficon"><a href="content/lectures/02%20-%20Recommendation%201.pdf" target="_blank"><span>2</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
                  <span class="pdficon"><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/02.1%20-%20Collaborative%20Filtering.ipynb" target="_blank"><span>2.1</span><sup><img src="site/images/icons/ipynbicon_small.png"></sup></a></span>
                  <span class="pdficon"><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/02.2%20-%20Movie%20Rating.ipynb" target="_blank"><span>2.2</span><sup><img src="site/images/icons/ipynbicon_small.png"></sup></a></span>

                </div>
                <!--<div class="lecture-notes">
                  <span class="pdficon"><a href="" target="_blank"><span>2</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
                  <span class="pdficon"><a href="" target="_blank"><span>2</span><sup><img src="site/images/icons/ipynbicon_small.png"></sup></a></span>
		<span class="pdficon"><a href="" target="_blank"><span>2</span><sup><img src="site/images/icons/ipynbicon_small.png"></sup></a></span>
                </div>-->
              </div>
            </div>
            <div class="sep-first"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="schedule-row">
              <div class="schedule-week">Week&nbsp;2<br/>(1/20&ndash;1/26)</div>
              <div class="schedule-keys key-topic-1"></div>
              <div class="schedule-keys key-topic-2"></div>
              <div class="schedule-keys"></div>
              <div class="schedule-day">Basics of (machine) learning. Classes and features. Types of data.<br/><em class="italic">(pp. 23&ndash;36)</em></div>
              <div class="schedule-day">Summary statistics. Data missingness.<br/><em class="italic">(pp. 97&ndash;105)</em></div>
              <div class="schedule-day">Data visualization.<br/><em class="italic">(pp. 105&ndash;131)</em></div>
              <div class="schedule-notes">
                <span class="pdficon"><a href="content/lectures/03%20-%20Data%20&%20Learning.pdf" target="_blank"><span>3</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span><br/>
              
                <span class="pdficon"><a href="content/lectures/04%20-%20Data%20Understanding.pdf" target="_blank"><span>4</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
                <span class="pdficon"><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/04%20-%20Summary%20Statistics%20and%20Basic%20Plotting.ipynb" target="_blank"><span>4</span><sup><img src="site/images/icons/ipynbicon_small.png"></sup></a></span><br/>
				
				<span class="pdficon"><a href="content/lectures/05%20-%20Data%20Visualization.pdf" target="_blank"><span>5</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
				<span class="pdficon"><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/05%20-%20Baby%20Names.ipynb" target="_blank"><span>5</span><sup><img src="site/images/icons/ipynbicon_small.png"></sup></a></span><br/>
		      </div>
            </div>
            <div class="sep-first"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="schedule-row">
              <div class="schedule-week">Week&nbsp;3<br/>(1/27&ndash;2/2)</div>
              <div class="schedule-keys key-topic-3"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-day">Data quality. Imputing data.<br/><em class="italic">(pp. 36&ndash;44)</em></div>
              <div class="schedule-day">Standardizing data. Sampling data.<br/><em class="italic">(pp. 44&ndash;50)</em></div>
              <div class="schedule-day">Dimensionality reduction. PCA.<br/><em class="italic">(pp. 50&ndash;52, 701&ndash;705)</em></div>
              <div class="schedule-notes">
		<span class="pdficon"><a href="content/lectures/06%20-%20Data%20Quality.pdf" target="_blank"><span>6</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
        <span class="pdficon"><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/06%20-%20Working%20With%20Missing%20Data.ipynb" target="_blank"><span>6</span><sup><img src="site/images/icons/ipynbicon_small.png"></sup></a></span><br/>
		
        <span class="pdficon"><a href="content/lectures/07%20-%20Data%20Transformation.pdf" target="_blank"><span>7</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
        <span class="pdficon"><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/07%20-%20Data%20Transformation.ipynb" target="_blank"><span>7</span><sup><img src="site/images/icons/ipynbicon_small.png"></sup></a></span><br/>
        
        <span class="pdficon"><a href="content/lectures/08%20-%20Dimensionality%20Reduction.pdf" target="_blank"><span>8</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
        <span class="pdficon"><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/08%20-%20Dimensionality%20Reduction.ipynb" target="_blank"><span>8</span><sup><img src="site/images/icons/ipynbicon_small.png"></sup></a></span><br/>
		</div>
            </div>
            <div class="sep-first"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="schedule-row">
              <div class="schedule-week">Week&nbsp;4<br/>(2/3&ndash;2/9)</div>
              <div class="schedule-keys key-topic-4"></div>
              <div class="schedule-keys key-topic-6"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-day">Introduction to association rules. Market basket analysis.<br/><em class="italic">(pp. 327&ndash;333)</em></div>
              <div class="schedule-day">The Apriori algorithm.<br/><em class="italic">(pp. 333&ndash;338, 350&ndash;352)</em></div>
              <div class="schedule-day">FP-Growth.<!-- Correlation analysis.--> Evaluating association patterns.<br/><em class="italic">(pp. 363&ndash;386)</em></div>
              <div class="schedule-notes">
              <span class="pdficon"><a href="content/lectures/09%20-%20Association%20Rules.pdf" target="_blank"><span>9</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span><br/>
              <span class="pdficon"><a href="content/lectures/10%20-%20Apriori.pdf" target="_blank"><span>10</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
              <span class="pdficon"><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/10%20-%20Apriori.ipynb" target="_blank"><span>10</span><sup><img src="site/images/icons/ipynbicon_small.png"></sup></a></span><br/>
              <span class="pdficon"><a href="content/lectures/11%20-%20FP-Growth%20&%20Evaluation.pdf" target="_blank"><span>11</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
              <span class="pdficon"><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/11%20-%20FP-Growth.ipynb" target="_blank"><span>11</span><sup><img src="site/images/icons/ipynbicon_small.png"></sup></a></span><br/>
              </div>
            </div>
            <div class="sep-first"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="schedule-row">
              <div class="schedule-week">Week&nbsp;5<br/>(2/10&ndash;2/16)</div>
              <div class="schedule-keys key-topic-4"></div>
              <div class="schedule-keys  key-topic-6"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-day"><span class="italic">k</span>-means<!-- and <span class="italic">k</span>-medoids--> clustering. Determining the number of clusters.<br/><em class="italic">(pp. 490&ndash;513)</em></div>
              <div class="schedule-day">Hierarchical clustering.<br/><em class="italic">(pp. 515&ndash;526)</em></div>
              <div class="schedule-day">Mixture models. EM algorithm.<br/><em class="italic">(pp. 583&ndash;593)</em></div>
              <div class="schedule-notes">
              <span class="pdficon"><a href="content/lectures/12%20-%20k-means%20Clustering.pdf" target="_blank"><span>12</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
              <span class="pdficon"><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/12%20-%20k-means%20Clustering.ipynb" target="_blank"><span>12</span><sup><img src="site/images/icons/ipynbicon_small.png"></sup></a></span><br/>
              <span class="pdficon"><a href="content/lectures/13%20-%20Hierarchical%20Clustering.pdf" target="_blank"><span>13</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
              <span class="pdficon"><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/13%20-%20Hierarchical%20Clustering.ipynb" target="_blank"><span>13</span><sup><img src="site/images/icons/ipynbicon_small.png"></sup></a></span><br/>
			  <span class="pdficon"><a href="content/lectures/14%20-%20EM%20&%20Evaluation.pdf" target="_blank"><span>14</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
              </div>
            </div>
            <div class="sep-first"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="schedule-row">
              <div class="schedule-week">Week&nbsp;6<br/>(2/17&ndash;2/23)</div>
              <div class="schedule-keys key-topic-5"></div>
              <div class="schedule-keys key-topic-6"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-day">Evaluating clusters.<br/><em class="italic">(pp. 532&ndash;555)</em></div>
              <div class="schedule-day">Review of linear regression. Logistic regression. Regression evaluation.<br/><em class="italic">(pp. 730&ndash;735, 735&ndash;736)</em></div>
              <div class="schedule-day"><em class="italic">Invited Speaker from SAP</em></div>
              <div class="schedule-notes">
			  <span class="pdficon"><a href="content/lectures/15-16%20-%20Regression.pdf" target="_blank"><span>15-16</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span><br/>
			  <span class="pdficon"><a href="content/lectures/SAP%20Lecture.zip" target="_blank"><span>17</span><sup><img src="site/images/icons/zipicon_small.png"></sup></a></span>
			  </div>
            </div>
            <div class="sep-first"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="schedule-row">
              <div class="schedule-week">Week&nbsp;7<br/>(2/24&ndash;3/2)</div>
              <div class="schedule-keys key-topic-5"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-day">Introduction to classification. Nearest neighbor classification.<br/><em class="italic">(pp. 145&ndash;149, 223&ndash;227)</em></div>
              <div class="schedule-day">Bayes' Theorem. Bayesian learners.<br/><em class="italic">(pp. 227&ndash;231)</em></div>
              <div class="schedule-day">Na&iuml;ve Bayes algorithm.<br/><em class="italic">(pp. 231&ndash;238)</em></div>
              <div class="schedule-notes">
			  <span class="pdficon"><a href="content/lectures/18%20-%20NN%20Perceptron.pdf" target="_blank"><span>18</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
			  <span class="pdficon"><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/18%20-%20KNN.ipynb" target="_blank"><span>18</span><sup><img src="site/images/icons/ipynbicon_small.png"></sup></a></span><br/>
			  <span class="pdficon"><a href="content/lectures/19%20-%20Bayesian Classifiers.pdf" target="_blank"><span>19</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span><br/>
			  <span class="pdficon"><a href="content/lectures/20%20-%20Naive%20Bayes.pdf" target="_blank"><span>20</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
			  </div>
            </div>
            <div class="sep-first"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="schedule-row">
              <div class="schedule-week">Week&nbsp;8<br/>(3/3&ndash;3/9)</div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-day"><em class="italic">Review for Midterm Exam</em></div>
              <div class="schedule-day"><em class="italic">Midterm Exam</em></div>
              <div class="schedule-day"><strong class="bold">Mid-Term Break</strong></div>
              <div class="schedule-notes">
              <span class="pdficon"><a href="content/exams/midterm_sol.pdf" target="_blank"><span>Midterm</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
              </div>
            </div>
            <div class="sep-first"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="schedule-row">
              <div class="schedule-week">Week&nbsp;9<br/>(3/10&ndash;3/16)</div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-day"><strong class="bold">Mid-Term Break</strong></div>
              <div class="schedule-day"><strong class="bold">Mid-Term Break</strong></div>
              <div class="schedule-day"><strong class="bold">Mid-Term Break</strong></div>
              <div class="schedule-notes"></div>
            </div>
            <div class="sep-first"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="schedule-row">
              <div class="schedule-week">Week&nbsp;10<br/>(3/17&ndash;3/23)</div>
              <div class="schedule-keys key-topic-5"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-day">Rule-based learners.<br/><em class="italic">(pp. 207&ndash;223)</em></div>
              <div class="schedule-day">Classification trees. Information gain.<br/><em class="italic">(pp. 150&ndash;163)</em></div>
              <div class="schedule-day">Classification trees. Gain ratio. Gini index.<br/><em class="italic">(pp. 163&ndash;172)</em></div>
              <div class="schedule-notes">
			  <span class="pdficon"><a href="content/lectures/21%20-%20Rule-Based%20Classifiers.pdf" target="_blank"><span>21</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span><br/>
			  <span class="pdficon"><a href="content/lectures/22%20-%20Decision%20Trees.pdf" target="_blank"><span>22</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span><br/>
              <span class="pdficon"><a href="content/lectures/23%20-%20Decision%20Trees%202.pdf" target="_blank"><span>23</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
              <span class="pdficon"><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/23%20-%20Decision%20Trees.ipynb" target="_blank"><span>23</span><sup><img src="site/images/icons/ipynbicon_small.png"></sup></a></span>
			  </div>
            </div>
            <div class="sep-first"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="schedule-row">
              <div class="schedule-week">Week&nbsp;11<br/>(3/24&ndash;3/30)</div>
              <div class="schedule-keys key-topic-5"></div>
              <div class="schedule-keys key-topic-6"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-day">Overfitting. Evaluating classifiers.<br/><em class="italic">(pp. 172&ndash;186)</em></div>
              <div class="schedule-day">Imbalanced data. Precision and recall. ROC curves.<br/><em class="italic">(pp. 294&ndash;304)</em></div>
              <div class="schedule-day">Precision-recall (PR) curves. Lift curves.<br/><em class="italic"></em></div>
               <div class="schedule-notes">
               <span class="pdficon"><a href="content/lectures/24%20-%20Decision%20Trees%203.pdf" target="_blank"><span>24</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span><br/>
               <span class="pdficon"><a href="content/lectures/25-26%20-%20Classifier%20Evaluation.pdf" target="_blank"><span>25-26</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
               </div>
            </div>
            <div class="sep-first"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="schedule-row">
              <div class="schedule-week">Week&nbsp;12<br/>(3/31&ndash;4/6)</div>
              <div class="schedule-keys key-topic-5"></div>
              <div class="schedule-keys key-topic-6"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-day">Cross-validation. Bootstrapping.<br/><em class="italic">(pp. 186&ndash;188)</em></div>
              <div class="schedule-day">Comparing classifiers. Statistical significance testing.<br/><em class="italic">(pp. 188&ndash;192)</em></div>
              <div class="schedule-day">Bias-variance tradeoff. Jackknifing.<br/><em class="italic">(pp. 281&ndash;285)</em></div>
              <div class="schedule-notes">
			  <span class="pdficon"><a href="content/lectures/27%20-%20Performance%20Estimation.pdf" target="_blank"><span>27</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
              <span class="pdficon"><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/27%20-%20Evaluating%20Classifiers.ipynb" target="_blank"><span>27</span><sup><img src="site/images/icons/ipynbicon_small.png"></sup></a></span><br/>
              <span class="pdficon"><a href="content/lectures/28%20-%20Classifier%20Comparisons.pdf" target="_blank"><span>28</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span><br/>
			  <span class="pdficon"><a href="content/lectures/29%20-%20Bias%20Variance.pdf" target="_blank"><span>29</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
			  </div>
            </div>
            <div class="sep-first"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="schedule-row">
              <div class="schedule-week">Week&nbsp;13<br/>(4/7&ndash;4/13)</div>
              <div class="schedule-keys key-topic-5"></div>
              <div class="schedule-keys key-topic-7"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-day">Bagging. Boosting.<br/><em class="italic">(pp. 283&ndash;290)</em></div>
			  <div class="schedule-day">Random subspaces. Random forests.<br/><em class="italic">(pp. 290&ndash;294)</em></div>
              <div class="schedule-day">Stacking / blending.</div>
              <div class="schedule-notes">
			  <span class="pdficon"><a href="content/lectures/30%20-%20Bagging%20Boosting.pdf" target="_blank"><span>30</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
              <span class="pdficon"><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/30%20-%20Boosting.ipynb" target="_blank"><span>30</span><sup><img src="site/images/icons/ipynbicon_small.png"></sup></a></span><br/>
			  <span class="pdficon"><a href="content/lectures/31%20-%20Decision%20Tree%20Ensembles.pdf" target="_blank"><span>31</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
              <span class="pdficon"><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/31%20-%20Decision%20Tree%20Ensembles.ipynb" target="_blank"><span>31</span><sup><img src="site/images/icons/ipynbicon_small.png"></sup></a></span><br/>
			  <span class="pdficon"><a href="content/lectures/32%20-%20Stacking.pdf" target="_blank"><span>32</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
              <span class="pdficon"><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/32%20-%20Stacking%20&%20Blending.ipynb" target="_blank"><span>32</span><sup><img src="site/images/icons/ipynbicon_small.png"></sup></a></span>
			  </div>
            </div>
            <div class="sep-first"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="schedule-row">
              <div class="schedule-week">Week&nbsp;14<br/>(4/14&ndash;4/20)</div>
              <div class="schedule-keys key-topic-7"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-day"><em class="italic">(Advanced topics)</em> Artificial Neural Networks (ANNs).</div>
              <div class="schedule-day"><em class="italic">(Advanced topics)</em> Self-Taught Learning.</div>
              <div class="schedule-day"><strong class="bold">Easter Holiday</strong></div>
              <div class="schedule-notes">
              <span class="pdficon"><a href="content/lectures/33%20-%20ANNs.pdf" target="_blank"><span>33</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
              <span class="pdficon"><a href="http://nbviewer.ipython.org/github/cse40647/cse40647/blob/sp.14/33%20-%20Artificial%20Neural%20Networks.ipynb" target="_blank"><span>33</span><sup><img src="site/images/icons/ipynbicon_small.png"></sup></a></span><br/>
			  <span class="pdficon"><a href="content/lectures/34%20-%20Self-Taught%20Learning.pdf" target="_blank"><span>34</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span><br/>
              </div>
            </div>
            <div class="sep-first"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="schedule-row">
              <div class="schedule-week">Week&nbsp;15<br/>(4/21&ndash;4/27)</div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-day"><strong class="bold">Easter Holiday</strong></div>
              <div class="schedule-day"><em class="italic">(Advanced topics)</em> Support Vector Machines (SVMs).</div>
              <div class="schedule-day">Collaborative filtering (part II).</div>
              <div class="schedule-notes">
              <span class="pdficon"><a href="content/lectures/36%20-%20Recommendation%202.pdf" target="_blank"><span>36</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
              </div>
            </div>
            <div class="sep-first"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="sep"><hr class="hr-row"></div>
            <div class="schedule-row">
              <div class="schedule-week">Week&nbsp;16<br/>(4/28&ndash;5/4)</div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-keys-empty"></div>
              <div class="schedule-day">Concluding discussion.</div>
              <div class="schedule-day"><em class="italic">Review for Final Exam</em></div>
              <div class="schedule-day"></div>
              <div class="schedule-notes">
              <span class="pdficon"><a href="content/exams/final_sol.pdf" target="_blank"><span>Final</span><sup><img src="site/images/icons/pdficon_small.png"></sup></a></span>
              </div>
            </div>
            <div class="sep"><hr class="hr-bottom"></div>
            <div class="sep"><hr class="hr-bottom"></div>
            <div class="sep"><hr class="hr-bottom"></div>
            <div class="sep"><hr class="hr-bottom"></div>
            <div class="sep"><hr class="hr-bottom"></div>
            <div class="sep"><hr class="hr-bottom"></div>
            <div class="sep"><hr class="hr-bottom"></div>
            <div class="sep"><hr class="hr-bottom"></div>
          </div>
          <br/>
        </div>
        <div class="clearer"></div>
        <div><center><a href="#" class="topOfPage">Top</a></center></div>
<?php include('site/includes/bottom.php'); ?>
