<?php include('site/includes/top.php'); ?>
        <script>
        document.title = "<?php echo $course ?> Project";
        </script>
        <div id="contents">
          <h1>Course Project</h1>
          <br/>
          <p class="text">To bring together and apply the various topics covered in this course, you will work on a data mining project. The goal of the project is to go through the complete knowledge discovery process to answer one or more questions you have about a topic of your own choosing. You will acquire the data, formulate a question (or questions) of interest, perform the data analysis, and communicate the results.</p>

          <h3>Project Team</h3>
          <p class="text">Undergraduate students are encouraged to work in teams of 2&ndash;4 (with a maximum of 4 members) for the course project. Graduate students are encouraged to work in teams of 2, unless there is a specific project related to their thesis/work, which should be discussed with the <?php echo $instructor ?>.</p>

          <h3>Project Milestones</h3>
          <p class="text padding-bottom">There are a few milestones for your final project. It is critical to note that <strong class="bold">no extensions will be given</strong> for any of the project due dates for any reason. Projects submitted after the final due date will not be graded. If you anticipate any issues you need to send an email to the <?php echo $instructor ?> at least one week in advance. Unless otherwise announced, all submission deadlines are at <strong class="bold">11:59pm ET</strong> on the assigned due date.</p>
          <p class="text padding-bottom">Monday, March 17:  Project proposals due</p>
          <p class="text padding-bottom">Week of March 24:  Project review meeting</p>
          <p class="text padding-bottom">Monday, April 28:  Draft paper due (optional)</p>
          <p class="text padding-bottom">Thursday, May 1 (4pm):  Project presentations</p>
          <p class="text">Monday, May 5 (before the final exam):  Final deliverables due</p>

          <h2>Deliverables</h2>
          <p class="text">There are several deliverables for your project that will be graded individually to make up your final project score.</p>

          <h3>Proposal</h3>
          <p class="text">You start your project by forming your groups and letting the <?php echo $instructor ?> know what topic you are interested in exploring<!-- by submitting this <span class="link"><a href="">project proposal form</a></span>-->.<!-- <strong class="bold">Each team will only need to submit one form.</strong>--> The proposal should be an informal written document submitted to the <?php echo $instructor ?> in person or via email. The <?php echo $instructor ?> will schedule a project review meeting with you during the week marked in the schedule. Make sure all of your team members are present at the meeting.</p>
          
          <h3>Project Presentation</h3>
          <p class="text">Each group will explain their project in a 10&ndash;15 minute presentation to the class. Presentations should clearly convey the project ideas, methods, and results, including the question(s) being addressed, the motivation of the analyses being employed, and relevant evaluations, contributions, and discussion questions.</p>

          <h3>Project Paper</h3>
          <p class="text">The projects will be concluded with project paper. Your paper should summarize your steps in developing your solution, including how you collected the data, the method you used, and the insights obtained. The paper should be submitted in Word or PDF format. Optionally, you may submit a draft paper (in person or via email) by the listed deadline to receive feedback from the <?php echo $instructor ?> prior to the final paper deadline.</p>

          <h2>Grading</h2>
          
          <p class="text padding-bottom">70% of the project grade will be based on your project paper.<!-- 20% of the grade will be based on your code. This includes the quality of your data analysis and Python code, the complexity and level of difficulty of your project, completeness and overall functionality of your analysis.--> 20% of the grade will be based on your project presentation. The remaining 10% of the grade will be based on your project proposal.</p>
          
          <p class="text">The <strong class="bold">project proposal</strong> will be graded as follows:</p>

          <table class="gradingrubric-table">
            <tr class="gradingrubric-row">
              <td class="title">Title of Project:</td>
              <td class="header">&nbsp;&nbsp;5%</td>
              <td class="content">What's the title of the project?</td>
            </tr>
            <tr class="gradingrubric-row">
              <td class="title">Project Plan:</td>
              <td class="header">30%</td>
              <td class="content">What do you plan to do?</td>
            </tr>
            <tr class="gradingrubric-row">
              <td class="title">Data Sources:</td>
              <td class="header">20%</td>
              <td class="content">What data do you plan to use? From where will this data come?</td>
            </tr>
            <tr class="gradingrubric-row">
              <td class="title">Proposed Evaluation:</td>
              <td class="header">30%</td>
              <td class="content">How do you plan to evaluate your proposed method? How will you determine whether the method is successful?</td>
            </tr>
            <tr class="gradingrubric-row">
              <td class="title">Writing Quality:</td>
              <td class="header">15%</td>
              <td class="content">Clarity of expression (5%), organization (5%), and grammar (5%).</td>
            </tr>
          </table>
          
          <p class="text padding-top">The <strong class="bold">project presentation</strong> will be graded as follows:</p>

          <table class="gradingrubric-table">
            <tr class="gradingrubric-row">
              <td class="title">Introduction:</td>
              <td class="header">15%</td>
              <td class="content">Provide context. What questions are being addressed?</td>
            </tr>
            <tr class="gradingrubric-row">
              <td class="title">Solution/Method:</td>
              <td class="header">30%</td>
              <td class="content">What did you do? Why did you choose this method? What tools and techniques did you use?</td>
            </tr>
            <tr class="gradingrubric-row">
              <td class="title">Data and Experiments:</td>
              <td class="header">10%</td>
              <td class="content">What data did you use? Are your experimental methods reliable?</td>
            </tr>
            <tr class="gradingrubric-row">
              <td class="title">Evaluation and Results:</td>
              <td class="header">30%</td>
              <td class="content">What evaluation did you do? Do your conclusions match your results?</td>
            </tr>
            <tr class="gradingrubric-row">
              <td class="title">Presentation Quality:</td>
              <td class="header">15%</td>
              <td class="content">Clarity of speaking (5%), organization (5%), and visuals (5%).</td>
            </tr>
          </table>
          
          
          <p class="text padding-top">The <strong class="bold">project paper</strong> will be graded as follows:</p>

          <table class="gradingrubric-table">
            <tr class="gradingrubric-row">
              <td class="title">Introduction:</td>
              <td class="header">15%</td>
              <td class="content">Provide context and motivation. What questions are being addressed? Why are these questions interesting or important?</td>
            </tr>
            <tr class="gradingrubric-row">
              <td class="title">Related Work:</td>
              <td class="header">10%</td>
              <td class="content">What other methods have addressed these or similar questions? How do these methods differ from your method?</td>
            </tr>
            <tr class="gradingrubric-row">
              <td class="title">Solution/Method:</td>
              <td class="header">25%</td>
              <td class="content">What did you do? What tools and techniques did you use? Was any innovation attempted?</td>
            </tr>
            <tr class="gradingrubric-row">
              <td class="title">Data and Experiments:</td>
              <td class="header">10%</td>
              <td class="content">What data did you use? Are your experimental methods reliable? What preprocessing was done the data?</td>
            </tr>
            <tr class="gradingrubric-row">
              <td class="title">Evaluation and Results:</td>
              <td class="header">25%</td>
              <td class="content">Did you properly evaluate your experiments? Did you test for statistical significance? Do your conclusions match your results?</td>
            </tr>
            <tr class="gradingrubric-row">
              <td class="title">Writing Quality:</td>
              <td class="header">15%</td>
              <td class="content">Clarity of writing (5%), organization (5%), and grammar (5%).</td>
            </tr>
          </table>

          <h2>Submission Instructions</h2>
          <p class="text">To submit your project deliverables, create a folder named <strong class="bold">netid_project</strong> and place your files in this folder. The folder should include your project paper (Word or PDF format), presentation materials, and all code and output used to generate results. Compress the folder (please use .zip compression) and submit it to your <?php echo $course ?> dropbox folder via <a href="https://webfile.nd.edu/" target="_blank">WebFile</a> or SCP. Your course dropbox folder is located at <span class="break-word">&ldquo;<?php echo $course_dir ?>/dropbox/yourNetID&rdquo;</span> on <a href="http://oithelp.nd.edu/shared-file-space/afs/" target="_blank">the AFS file space</a>. <em class="italic">If we cannot access your work because these directions are not followed correctly, we will not grade your work. </em> You can submit once per team or submit once per team member.</p>
          <br/>
        </div>
        <div class="clearer"></div>
        <div><center><a href="#" class="topOfPage">Top</a></center></div>
<?php include('site/includes/bottom.php'); ?>