<?php include('site/variables/variables.php'); ?>
  <link rel="stylesheet" type="text/css" media="screen" href="site/themes/<?php echo $stylesheet ?>/reset.css"/>
  <link id="mainstyle" rel="stylesheet" type="text/css" media="screen" href="site/themes/<?php echo $stylesheet ?>/styles.css"/>
  <!--[if IE 6]><link rel="stylesheet" type="text/css" media="screen" href="site/themes/<?php echo $stylesheet ?>/ie6.css"  /><![endif]-->
  <!--[if IE 7]><link rel="stylesheet" type="text/css" media="screen" href="site/themes/<?php echo $stylesheet ?>/ie7.css"  /><![endif]-->
  <link rel="stylesheet" type="text/css" media="screen" href="site/themes/<?php echo $stylesheet ?>/colors.css"/>
  <link rel="stylesheet" type="text/css" media="screen" href="site/themes/<?php echo $stylesheet ?>/css/background/colorpicker.css"/>
  <link rel="stylesheet" type="text/css" media="screen" href="site/themes/<?php echo $stylesheet ?>/css/top/normal.css"/>
  <link rel="stylesheet" type="text/css" media="screen" href="site/themes/<?php echo $stylesheet ?>/css/archives/archives_on.css"/>
  <link rel="stylesheet" type="text/css" media="screen" href="site/themes/<?php echo $stylesheet ?>/css/sidebar/sidebar_hidden.css"/>
  <!--<link rel="stylesheet" type="text/css" media="screen" href="site/themes/<?php echo $stylesheet ?>/css/sidebar/blue-glass/sidebar.css"/>-->
  <link rel="stylesheet" type="text/css" media="screen" href="site/themes/<?php echo $stylesheet ?>/css/breadcrumb/breadcrumb_off.css"/>
  <link rel="stylesheet" type="text/css" media="screen" href="site/themes/<?php echo $stylesheet ?>/css/font/arial.css"/>
  <style type="text/css">img,div,input{behavior:url(themes/<?php echo $stylesheet ?>/iepngfix.htc)}</style>
  <script>
  var fileref=document.createElement("link")
  fileref.setAttribute("rel", "stylesheet")
  fileref.setAttribute("type", "text/css")
  fileref.setAttribute("href", 'site/themes/<?php echo $stylesheet ?>/menu-styles.css')
  document.getElementsByTagName("head")[0].appendChild(fileref)
  </script>
