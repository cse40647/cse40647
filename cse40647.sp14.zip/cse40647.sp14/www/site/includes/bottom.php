      </div>
      <div class="clearer"></div>
    </div>
    <!-- Start Breadcrumb -->
    <div id="breadcrumb">
      <div id="breadcrumb-inset"></div>
      <div id="search-inset">
       <div id="searchtext">Search site: </div>
        <div id="searchform">
          <form method="get" class="search" action="http://www.google.com/search">
            <input type="search" name="q" class="search-input" placeholder="Search" title="type your search term" tabindex="1" accesskey="4">
            <!--<input type="search" name="q" class="search-input" value="Search" autosave="search" results="10" onblur="if (this.value =='') {this.value ='Search';}" onfocus="if (this.value =='Search') {this.value ='';}"/>-->
            <input type="hidden" name="domains" value="<?php echo "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; ?>"/>
            <input type="hidden" name="sitesearch" value="<?php echo "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; ?>"/>
            <button type="submit" class="search-button">Search</button>
          </form>
        </div>
      </div>
      <div class="clearer"></div>
    </div>
    <!-- End Breadcrumb -->
    <!-- Start Footer -->
    <div id="footer"><?php echo $footer ?></div>
    <!-- End Footer -->
  </div>
  <!-- Start Google Analytics -->
<?php include('site/includes/ga.php'); ?>
  <!-- End Google Analytics -->
</body>