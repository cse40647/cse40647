<?php include('site/variables/variables.php'); ?>
  <script type="text/javascript" src="site/js/jquery-1.11.2.min.js"></script>
  <script type="text/javascript" src="site/js/respond.min.js"></script>
  <script type="text/javascript" src="site/js/jquery.scrollTo.min.js"></script>
  <script type="text/javascript" src="site/js/jquery.localScroll.min.js"></script>
  <!--<script type="text/javascript" src="https://maps.google.com/maps/api/js?sensor=false"></script>-->
  <script type="text/javascript" src="site/js/jquery.carouFredSel.min.js"></script>
  <script type="text/javascript" src="site/js/jquery.touchSwipe.min.js"></script>
  <script type="text/javascript" src="site/js/custom.js"></script>
  <script type="text/javascript" charset="utf-8">var blankImg="site/themes/<?php echo $stylesheet ?>/blank.gif";</script>
