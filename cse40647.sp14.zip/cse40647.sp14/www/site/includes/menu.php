    <div id="menu-inset">
      <nav class="menu">
        <ul class="tabs">
          <li class="tmenu"><a href="home.php">Home</a></li>
          <li class="tmenu"><a href="syllabus.php">Syllabus</a></li>
          <li class="tmenu"><a href="schedule.php">Schedule</a></li>
          <li class="tmenu"><a href="assignments.php">Assignments</a></li>
          <li class="tmenu"><a href="project.php">Project</a></li>
          <li class="tmenu"><a href="https://sakailogin.nd.edu/xsl-portal/site/175efc85-fcc2-4704-bb3b-39df7e068f2a" target="_blank">Sakai</a></li>
          <li class="tmenu"><a href="resources.php">Resources</a></li>
        </ul>
        <a class="prev hidden disabled nodecoration" id="menu-prev" href="#">&#xe073;</a>
        <a class="next hidden disabled nodecoration" id="menu-next" href="#">&#xe076;</a>
      </nav>
    </div>
    <script language="javascript">setPage()</script>
