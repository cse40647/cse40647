top.php             combines all includes used in the top of each page
bottom.php          combines all includes used in the bottom of each page
stylesheets.php     CSS code (included in top.php)
javascript.php      JavaScript code (included in top.php)
menu.php            menu code (included in top.php)
ga.php              Google Analytics code (included in bottom.php)