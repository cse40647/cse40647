<?php include('site/variables/variables.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <script type="text/javascript">var _gaq=_gaq||[];_gaq.push(['_setSiteSpeedSampleRate',100]);</script>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta name="description" content="<?php echo $description ?>"/>
  <meta name="keywords" content="<?php echo $keywords ?>"/>
  <link rel="icon" href="site/icons/<?php echo $favicon ?>" type="image/x-icon"/>
  <link rel="shortcut icon" href="site/icons/<?php echo $favicon ?>" type="image/x-icon"/>
  <link rel="apple-touch-icon" href="site/icons/<?php echo $webclip ?>"/>
  <title><?php echo $course ?> <?php echo $course_title ?></title>
<?php include('site/includes/stylesheets.php'); ?>
<?php include('site/includes/javascript.php'); ?>
</head>
<body>
  <div id="container">
    <div id="header">
      <div id="customHeader">
        <div id="logo"><img src="site/images/<?php echo $ndmark ?>" width="<?php echo $ndmark_width ?>" height="<?php echo $ndmark_height ?>" alt="Site logo"/></div>
        <div id="siteTitle">
          <h1><a href="index.php" class="nodecoration"><?php echo $course_title ?></a></h1>
          <h1></h1>
          <h2><a href="index.php" class="nodecoration"><?php echo $course ?> &mdash; <?php echo ucfirst($course_sem) . " " . $course_year ?></a></h2>
        </div>
      </div>
      <div class="clearer"></div>
    </div>
    <!-- Start Menu -->
<?php include('site/includes/menu.php'); ?>
    <!-- End Menu -->
    <div id="main">
      <div id="sidebarContainer">
        <div id="sidebarContent">
          <h3></h3>
        </div>
        <div id="archives"></div>
      </div>
      <div id="content">
