<?php

## Course Variables ##

$course       = 'CSE 40647/60647'; // course designation
$course_title = 'Data Mining'; // course title

$course_dept  = 'CSE'; // course department (acronym)
$course_num   = '40647'; // course number
$course_sec   = "01"; // course section

$course_year  = '2014'; // course year
$course_sem   = 'spring'; // course semester
$course_time  = 'M/W/F 9:25&ndash;10:15am'; // course lecture time
$course_loc   = '<a href="http://map.nd.edu/#/placemarks/1144/zoom/16/lat/41.69817511364383/lon/-86.23625970632936" target="_blank">DeBartolo Hall 131</a>'; // course lecture location
$course_final = 'Thursday, May 8 from 8&ndash;10am'; // course final exam date and time

// course file directory
$course_dir = '/afs/nd.edu/course' . substr(strtolower($course_sem), 0, 2) . '.' . substr($course_year, -2) . '/' . strtolower($course_dept) . '/' . strtolower($course_dept) . $course_num . '.' . $course_sec;

// course instructor designation
$instructor = "instructors";

## head ##

// meta
$description = 'Notre Dame ' . $course . ' ' . $course_title . ' Course';
$keywords = 'data mining everaldo aguiar reid johnson notre dame course big data machine learning python visualization data';

// link
$favicon = 'favicon.ico';
$webclip = 'webclip.png';

$stylesheet = 'blue_gold';

## header ##

$title = $course . ' ' . $course_title;

//$ndmark = 'nd_mark_blue.png';
//$ndmark_width = '300';
//$ndmark_height = '70';

$ndmark = 'engineering_mark_blue.png';
$ndmark_width = '239';
$ndmark_height = '70';

## footer ##

$footer = '&copy; 2014&ndash;' . date("Y") . ' University of Notre Dame';

?>