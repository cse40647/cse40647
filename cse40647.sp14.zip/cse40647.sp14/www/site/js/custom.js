/* ---------------------------------------------------------------------- */
/*	Custom JavaScript
/* ---------------------------------------------------------------------- */

jQuery(document).ready(function(){ 

	/* ---------------------------------------------------------------------- */
	/*	Logo
	/* ---------------------------------------------------------------------- */

	// Logo
	var $logo 	= $('#logo');

    if (location.href.indexOf("#") != -1) {
        $logo.show();
    }

	// Show logo 
	$('.menu .tabs a').click(function() {
	  $logo.fadeIn('slow');
	});
	// Hide logo
	$('.tab-profile').click(function() {
	  $logo.fadeOut('slow');
	});

	/* ---------------------------------------------------------------------- */
	/*	Menu
	/* ---------------------------------------------------------------------- */

	// Menu Navigation
	 $(".menu .tabs").carouFredSel({
        responsive          : true,
        direction           : "left",
 	    circular: false,
    	infinite: false,
        cookie: true,
        pagination  		: "#menu-controls",  
        auto    			: false,
        scroll 			: {
            items           : 1,
            duration        : 300,                        
            wipe    : false
        },
		prev	: {	
			button	: "#menu-prev",
			key		: "right"
		},
		next	: { 
			button	: "#menu-next",
			key		: "left"
		},
	    swipe: {
	        onTouch: true
	    },
        items: {
            width: 125,
            visible: {
              min: 2,
              max: 7
            }
        }           
    });

	/* ---------------------------------------------------------------------- */
	/*	Scrolling
	/* ---------------------------------------------------------------------- */

    // scroll to hash
     $.localScroll({
        //axis: 'xy',
        //queue: true, // one axis at a time
        hash: true
    });

    // scroll to top
    $('a.topOfPage').click(function(){
        $.scrollTo( 0, 1000);
        return false;
     });

});

/* ---------------------------------------------------------------------- */
/*	Menu functions
/* ---------------------------------------------------------------------- */

function extractPageName(hrefString) {
	var arr = hrefString.split('/');

	return  (arr.length < 2) ? hrefString : arr[arr.length-2].toLowerCase() + arr[arr.length-1].toLowerCase();
}

function setActiveMenu(arr, crtPage) {
	for (var i=0; i < arr.length; i++) {
		if(extractPageName(arr[i].href) == crtPage) {
			if (arr[i].parentNode.tagName != "NAV") {
				arr[i].id = "current";
				arr[i].parentNode.id = "current";
                break;
			}
		}
	}
}

function setPage() {
	hrefString = document.location.href ? document.location.href : document.location;
 
	if (document.getElementsByClassName("menu")[0] !=null )
	setActiveMenu(document.getElementsByClassName("menu")[0].getElementsByTagName("a"), extractPageName(hrefString));
}

/* ---------------------------------------------------------------------- */
/*	Function to generate "open in new window" link as W3C compliant
/* ---------------------------------------------------------------------- */

function externalLinks() {
    if (!document.getElementsByTagName) return;
    var anchors = document.getElementsByTagName("a");
    for (var i=0; i<anchors.length; i++) {
        var anchor = anchors[i];
        if (anchor.getAttribute("href") &&
        anchor.getAttribute("rel") == "external")
            anchor.target = "_blank";
    }
}
window.onload = externalLinks;