<?php include('site/includes/top.php'); ?>
        <script>
        document.title = "<?php echo $course ?> Syllabus";
        </script>
        <div id="contents">
          <h1>Course Syllabus</h1>
          <br/>
          <p class="text">The information on this page is available in abbreviated form <a href="content/syllabus-cse40647-sp14.pdf" target="_blank">here via PDF</a>. Please refer to this page for full details.</p>
          
          <h2 class="padding-bottom"><?php echo ucfirst($instructor) ?>:</h2>

          <div id="instructor-table">
            <div id="instructor-row-left">
              <p class="photo">
                <div class="photo-inner">
                  <img class="photo-top" src="content/images/photo_everaldo.png" height="104" width="87">
                </div>
              </p>
              <p class="photo-text-nopadding"><span><strong class="instructor-name">Everaldo Aguiar&ensp;</strong></span><span>PhD Student (CSE)</span></p>
              <p class="photo-text">
                <a href="mailto:eaguiar@nd.edu" target="_blank">eaguiar@nd.edu</a><br/>
                <a href="http://www.nd.edu/~eaguiar" target="_blank">www.nd.edu/~eaguiar</a><br/>
                <span>384L <a href="http://map.nd.edu/#/placemarks/1050/zoom/16/lat/41.70110699447497/lon/-86.23677469046022" target="_blank">Nieuwland Science Hall</a><br/>Office Hours:  Monday & Wednesay, 1&ndash;2pm</span>
              </p>
            </div>
            <div id="instructor-row-right">
              <p class="photo">
                <div class="photo-inner">
                  <img class="photo-top" src="content/images/photo_reid.png" height="104" width="87">
                </div>
              </p>
              <p class="photo-text-nopadding"><span><strong class="instructor-name">Reid Johnson&ensp;</strong></span><span>PhD Student (CSE)</span></p>
              <p class="photo-text">
                <a href="mailto:rjohns15@nd.edu" target="_blank">rjohns15@nd.edu</a><br/>
                <a href="http://www.nd.edu/~rjohns15" target="_blank">www.nd.edu/~rjohns15</a><br/>
                <span>384L <a href="http://map.nd.edu/#/placemarks/1050/zoom/16/lat/41.70110699447497/lon/-86.23677469046022" target="_blank">Nieuwland Science Hall</a><br/>Office Hours:  Tuesday & Thursday, 1&ndash;2pm</span>
              </p>
            </div>
          </div>
          <div class="clearer"></div>

          <h2>Welcome to <?php echo $course ?>!</h2>

          <h3>What is this course about?</h3>
          <p class="text">This course is about mining knowledge from data in order to gain useful insights and predictions. From theory to practice, we investigate all stages of the knowledge discovery process, which includes:</p>
          <ul>
            <li class="item"><em class="italic">data understanding</em> in order to rapidly evaluate data of interest;</li>
            <li class="item"><em class="italic">data preprocessing/wrangling</em> in order to get an informative, manageable dataset;</li>
            <li class="item"><em class="italic">exploratory data analysis</em> to generate hypotheses and intuition about the data;</li>
            <li class="item"><em class="italic">prediction</em> based on statistical tools such as regression, classification, and clustering; and</li>
            <li class="item"><em class="italic">interpretation</em> of results through visualization and careful evaluation.</li>
          </ul>

          <h3>Why take this course?</h3>
          <!--<p class="text"><span>Hal Varian, Chief Economist at Google, said that:</span></p><br/>
          <p class="text"><span class="quote">&ldquo;The sexy job in the next ten years will be statisticians… The ability to take data—to be able to understand it, to process it, to extract value from it, to visualize it, to communicate it&mdash;that's going to be a hugely important skill.&rdquo;</span></p>-->
          <p class="text">Every day, careful analysis of data is leading to new insights, discoveries, and opportunities. Consider, for example, the story of <a href="http://en.wikipedia.org/wiki/Billy_Beane" target="_blank">Billy Beane</a>, a sports manager who used an analytical, evidence-based approach to assemble a competitive baseball team. Consider the work of <a href="http://en.wikipedia.org/wiki/Nate_Silver" target="_blank">Nate Silver</a>, a statistician who weighted a variety of data to correctly pick the winner from all 50 states in the 2012 presidential election. Consider how companies like Amazon, Facebook, and Netflix use &ldquo;<a href="http://en.wikipedia.org/wiki/Big_data" target="_blank">big data</a>&rdquo; to generate recommendations that are made to millions of people each day. Yet while the potential benefits of more and more data are obvious, the increasing flood of data also presents challenges, with some companies describing themselves as &ldquo;drowning in data.&rdquo; Data mining equips you with the tools that are needed so that you can learn from the deluge of data <em class="italic">without</em> drowning.</p>

          <h3>What can I expect to learn?</h3>
          <p class="text">Upon successful completion of this course, you will be able to&hellip;</p>
          <ul>
            <li class="item">Demonstrate knowledge of key principles and techniques of data mining</li>
            <li class="item">Programmatically apply fundamental concepts of data mining</li>
            <li class="item">Use statistical methods and visualization to explore and prepare data</li>
            <li class="item">Describe the theoretical constructs and core processes of data mining</li>
            <li class="item">Demonstrate knowledge of various predictive modeling techniques</li>
            <li class="item">Use a data mining program to analyze data and develop predictive models</li>
            <li class="item">Compare and evaluate the accuracy of predictive models</li>
            <li class="item">Understand the ethical issues associated with data mining</li>
            <li class="item">Understand and discuss the role of data mining in society</li>
            <li class="item">Demonstrate knowledge of the emerging areas and applications of data mining</li>
          </ul>

          <h3>Who should take this course?</h3>
          <p class="text">The prerequisite for this course is demonstrable knowledge of Python programming or understanding of programming concepts such as variables, functions, loops, and basic Python data structures like lists and dictionaries. Both undergraduate and graduate students are welcome to take the course.</p>

          <h2>Required Textbook</h2>
          
          <p class="text padding-top">There is one required textbook for this course, from which relevant readings will be suggested as a supplement to class lectures. The required textbook is the following:</p>
          
          <p class="image">
            <div class="image-inner-right">
              <img class="image-right" src="content/images/books/978-0321321367.gif" height="155" width="122">
            </div>
            <span class="text"><a href="http://lccn.loc.gov/2005008721" target="_blank">Introduction to Data Mining, 1st Edition (Tan, Steinbach, &amp; Kumar, 2006)</a></span>
          </p>
          <p class="text padding-bottom">&ldquo;Introduction to Data Mining presents fundamental concepts and algorithms for those learning data mining for the first time. Each concept is explored thoroughly and supported with numerous examples. The text requires only a modest background in mathematics. Each major topic is organized into two chapters, beginning with basic concepts that provide necessary background for understanding each data mining technique, followed by more advanced concepts and algorithms.&rdquo;</p>
          <p>Supplementary material for this textbook is available <a href="http://www-users.cs.umn.edu/~kumar/dmbook/index.php" target="_blank">here</a>.</p>
          
          <h2>Recommended Textbook & Resources</h2>

          <p class="text padding-top">Suggested resources, including additional textual recommendations, are provided <a href="resources.php" target="_self">here</a> on the course website. However, the following textbook is particularly recommended as an aid to the programming content of the course:</p>

          <p class="image">
            <div class="image-inner-right">
              <img class="image-right" src="content/images/books/978-1449319793.gif" height="157" width="122">
            </div>
            <span class="text"><a href="http://lccn.loc.gov/2012538094" target="_blank">Python for Data Analysis (McKinney, 2013)</a></span>
          </p>
          <p class="text">&ldquo;Python for Data Analysis is concerned with the nuts and bolts of manipulating, processing, cleaning, and crunching data in Python. It is also a practical, modern introduction to scientific computing in Python, tailored for data-intensive applications. This is a book about the parts of the Python language and libraries you'll need to effectively solve a broad set of data analysis problems. This book is not an exposition on analytical methods using Python as the implementation language. Written by Wes McKinney, the main author of the pandas library, this hands-on book is packed with practical cases studies [sic]. It's ideal for analysts new to Python and for Python programmers new to scientific computing.&rdquo;</p>

          <h2>Course Components</h2>
          

          <h3>Lectures</h3>
          <p class="text">The class meets three times a week for lectures. The weekly schedule of lectures is posted <a href="schedule.php" target="_self">here</a> on the course website.</p>

          <h3>Assignments</h3>
          <p class="text">There will be several assignments, which are going to provide an opportunity to learn data mining skills and to assess your understanding of the material. See an assignment as an opportunity to learn, and not to &ldquo;earn points.&rdquo; The assignments will also be graded to reflect this objective. Further details on the course assignments can be found <a href="assignments.php" target="_self">here</a> on the course website.</p>
          
          <h3>Quizzes and Exams</h3>
          <p class="text">There will be several quizzes, one midterm exam, and one final exam. The midterm exam will cover concepts from roughly the first half of the course. The final exam will be cumulative, but the content will be weighted so that roughly two-thirds of the exam covers concepts from the second half of the course. The final exam will be held on <?php echo $course_final ?> in <?php echo $course_loc ?>.</p>

          <h3>Project</h3>
          <p class="text padding-bottom">Towards the end of the course you will work on a data mining project. The goal of the project is to go through the complete knowledge discovery process to answer one or more questions you have about a topic of your own choosing. You will acquire the data, formulate a question of interest, perform the data analysis, and communicate the results.</p>
          <p class="text padding-bottom">Undergraduate students are encouraged to work in teams of 2&ndash;4 (with a maximum of 4 members) for the course project. Graduate students are encouraged to work
in teams of 2, unless there is a specific project related to their thesis/work, which should be discussed with the <?php echo $instructor ?>.</p>
          <p class="text">Additional information on the course project can be found <a href="project.php" target="_self">here</a> on the course website.</p>

          <h2>Grading Policies</h2>

          <h3>Grading Procedure</h3>
          <p class="text">Your final grade will be determined by the number of points you collect, distributed as follows (subject to change):</p>

            <table class="gradingprocedure-table">
              <tr class="gradingprocedure-row">
                <td class="title">Participation:</td>
                <td class="header">&nbsp;&nbsp;5%</td>
                <td class="content">Assessed on participation during lectures and discussions.</td>
              </tr>
              <tr class="gradingprocedure-row">
                <td class="title">Quizzes:</td>
                <td class="header">10%</td>
                <td class="content">Distributed throughout the course.</td>
              </tr>
              <tr class="gradingprocedure-row">
                <td class="title">Assignments:</td>
                <td class="header">20%</td>
                <td class="content">Assessed on your individual submission.</td>
              </tr>
              <tr class="gradingprocedure-row">
                <td class="title">Course&nbsp;Project:</td>
                <td class="header">30%</td>
                <td class="content">Assessed on meeting the project criteria.</td>
              </tr>
              <tr class="gradingprocedure-row">
                <td class="title">Midterm&nbsp;Exam:</td>
                <td class="header">15%</td>
                <td class="content">Covering concepts from roughly the first half of the course.</td>
              </tr>
              <tr class="gradingprocedure-row">
                <td class="title">Final&nbsp;Exam:</td>
                <td class="header">20%</td>
                <td class="content">Cumulative, but with roughly 2/3 covering concepts from the second half of the course.</td>
              </tr>
              <tr class="gradingprocedure-row">
                <td class="title">Extra&nbsp;Credit:</td>
                <td class="header">+5%</td>
                <td class="content">Distributed at the discretion of the <?php echo $instructor ?>.</td>
              </tr>
            </table>

          <h3>Letter Grade Assignment</h3>
          <p class="text">The grade assignment will be based on the following guideline:</p>
          <table id="lettergrade-table">
            <tr>
              <td>
                <table class="lettergrade-subtable">
                  <tr>
                    <td><p class=" entityHeader">&ge; 90.00</p></td>
                    <td><p>A</p></td>
                  </tr>
                  <tr>
                    <td><p class=" entityHeader">87.00 &ndash; 89.99</p></td>
                    <td><p>A&minus;</p></td>
                  </tr>
                  <tr>
                    <td><p class=" entityHeader">83.00 &ndash; 86.99</p></td>
                    <td><p>B+</p></td>
                  </tr>
                  <tr>
                    <td><p class=" entityHeader">80.00 &ndash; 82.99</p></td>
                    <td><p>B</p></td>
                  </tr>
                  <tr>
                    <td><p class=" entityHeader">77.00 &ndash; 79.99</p></td>
                    <td><p>B&minus;</p></td>
                  </tr>
                </table>
              </td>
              <td class="sep"></td>
              <td>
                <table class="lettergrade-subtable">
                  <tr>
                    <td><p class=" entityHeader">73.00 &ndash; 76.99</p></td>
                    <td><p>C+</p></td>
                  </tr>
                  <tr>
                    <td><p class=" entityHeader">70.00 &ndash; 72.99</p></td>
                    <td><p>C</p></td>
                  </tr>
                  <tr>
                    <td><p class=" entityHeader">67.00 &ndash; 69.99</p></td>
                    <td><p>C&minus;</p></td>
                  </tr>
                  <tr>
                    <td><p class=" entityHeader">60.00 &ndash; 66.99</p></td>
                    <td><p>D</p></td>
                  </tr>
                  <tr>
                    <td><p class=" entityHeader">&le; 59.99</p></td>
                    <td><p>F</p></td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>

          <h3>Grade Assignment</h3>
          <p class="text">Grades in the <strong class="bold">C</strong> range represent performance that <strong class="bold">meets expectations</strong>. Grades in the <strong class="bold">B</strong> range represent performance that is <strong class="bold">substantially better</strong> than expectations. Grades in the <strong class="bold">A</strong> range represent work that is <strong class="bold">excellent</strong>. Graduate students will be held to a higher standard of grading, as they will be receiving graduate-level credit for the course.</p>

          <h3>Grade Reference</h3>
          <p class="text">Grades will be maintained on <a href="https://sakailogin.nd.edu/" target="_blank">Sakai</a>. Students are responsible for tracking their progress by referring to the online gradebook.</p>

          <h3>Grading Discrepancies</h3>
          <p class="text">It is very important to us that all work is properly graded. If you believe there is an error in the grading for any assignment, project, exam, or any other coursework, please submit an explanation to the <?php echo $instructor ?> via email<strong class="bold"> within 7 days of receiving the grade</strong>. No regrade requests will be accepted orally, and no regrade requests will be accepted more than 7 days after you have received the grade.</p>

          <h2>Course Policies</h2>

          <h3>Collaboration Policy</h3>
          <p class="text">You are encouraged to discuss the courses' ideas, materials, and assignments with others in order to better understand them. However, unless instructed otherwise, <strong class="bold">the work you turn in must be your own</strong> (or, for the project, yours and your teammates'). You must, for example, write your own code, run your own data analyses, and write up your own results and answers to assignment questions. You may not submit the same or similar work to this course that you have submitted or will submit to another. Nor may you provide or make available solutions to assignments to individuals who take or may take this course in the future.</p>

          <h3>Assignments</h3>
          <p class="text padding-bottom">Unless announced otherwise, assignments will be due at 11:59pm ET on the provided submission date.</p>
          <p class="text padding-bottom">Each assignment may have additional problems that graduate students must complete. Undergraduate students may earn extra credit for working on these problems.</p>
          <p class="text">Programming assignments will require the use of Python 2.7. Students will be provided with access to a virtual machine snapshot image that contains the software required for the course. All submitted code is expected to function properly using the software provided on the image file.</p>

          <h3>Quizzes and Exams</h3>
          <p class="text">Make-up quizzes and exams will be allowed as per the <a href="http://studenthandbook.nd.edu/academic/absence/" target="_blank">du Lac Class Absence Policy</a>. Whenever possible, you are expected to provide advance notice if you will be unable to take a quiz or exam. Make-up quizzes and exams for travel to academic conferences will be provided at the discretion of the <?php echo $instructor ?>.</p>

          <h3>Late Policy</h3>
          <p class="text padding-bottom">Assignments will be due at 11:59pm ET on the provided submission date, unless announced otherwise. Assignments submitted after the submission deadline but within the next day are counted as one day late. The next 24 hours will be counted as two days late, and so on. Each day late contributes a 10% penalty to the original assignment value. Assignments more than three days late will ordinarily receive a 0.</p>
          <p class="text">We understand that certain factors may occasionally interfere with your ability to hand in work on time. If that factor is an extenuating circumstance, we will ask you to provide documentation directly issued by the University, and we will try to work out an agreeable solution.</p>

          <h3>Academic Honesty</h3>
          <p class="text">A commitment to honesty is expected of all students. The <a href="http://studenthandbook.nd.edu/community-standards/standards/academic-codes/" target="_blank">du Lac Academic Codes</a>, which relate to academic integrity, will be strictly followed. All references and sources, both to text and code, should be properly cited in all submitted work. For programming work, you may, as a starting point, use code examples that you find, provided this use is permitted by the license. You are also encouraged to use libraries, unless explicitly stated otherwise. However, you must acknowledge any source code that was not written by you by mentioning the original author(s) directly in your source code (comment or header). You can also acknowledge sources in a README.txt file if you use whole classes or libraries.</p>

          <h2>Course Contents</h2>

          <p class="text padding-top">Details may change depending on time and class interests.</p>
          <ul>
            <li class="item"><span class="text-header">General Topics</span>
              <ul class="subitem">
                <p><em class="italic">Data Understanding</em>:  types of data; information and uncertainty; classes and attributes; interactions among attributes; relative distributions; summary statistics; data visualization</p>
              </ul>
              <ul class="subitem">
                <p><em class="italic">Data Quality</em>:  inaccurate data; sparse data; missing data; insufficient data; imbalanced data</p>
              </ul>
              <ul class="subitem">
                <p><em class="italic">Social Issues</em>:  data ownership; data security; ethics and privacy</p>
              </ul>
            </li>
            <li class="item"><span class="text-header">Unsupervised Learning Topics</span>
              <ul class="subitem">
                <p><em class="italic">Data Reduction and Feature Enhancement</em>:  standardizing data; sampling data; using principal components to eliminate attributes; limitations and pitfalls of principal component analysis (PCA)<!-- and factor analysis; nonlinear dimensionality reduction-->; curse of dimensionality</p>
              </ul>
              <ul class="subitem">
                <p><em class="italic">Clustering</em>:  dissimilarity and scatter; categorization;  <em class="italic">k</em>-means clustering<!--; <em class="italic">k</em>-medoids clustering-->; hierarchical clustering; distance measures; shape of clusters; determining the number of clusters; evaluating clusters</p>
              </ul>
              <ul class="subitem">
                <p><em class="italic">Association Analysis</em>:  association rule learning; the Apriori algorithm; FP-growth; market basket analysis</p>
              </ul>
            </li>
            <li class="item"><span class="text-header">Supervised Learning Topics</span>
              <ul class="subitem">
                <p><em class="italic">Regression</em>:  review of linear regression; assumptions underlying linear regression</p>
              </ul>
              <ul class="subitem">
                <p><em class="italic">Classification</em>:  supervised categorization; linear classifiers; logistic regression; regression trees; classification trees; Bayes' Theorem; na&iuml;ve Bayes; support vector machines (SVMs)<!--; artificial neural networks (ANNs)-->; confusion matrices; receiver operating characteristic (ROC) curves; precision and recall; lift curves; cost curves</p>
              </ul>
              <ul class="subitem">
                <p><em class="italic">Model Selection and Validation</em>:  training error and optimism; the Bayes error rate; inductive bias<!--; VC dimension-->; the bias-variance tradeoff; overfitting; Occam's Razor; minimum description length (MDL); sampling bias; the validation set approach; leave-one-out cross-validation; <em class="italic">k</em>-fold cross-validation; bootstrapping; jackknifing; data snooping</p>
              </ul>
              <ul class="subitem">
                <p><em class="italic">Ensemble Learning</em>:  bootstrap aggregating (bagging); boosting; stacking/blending; random subspaces; random forests</p>
              </ul>
            </li>
            <li class="item"><span class="text-header">Miscellaneous Topics (as time permits)</span>
              <ul class="subitem">
                <p><em class="italic">Recommender Systems</em>; <em class="italic">Reinforcement Learning</em>; <em class="italic">Active Learning</em>; <em class="italic">Semi-supervised Learning</em>; <em class="italic">Transfer Learning</em>; <em class="italic">Deep Learning</em>; <em class="italic">Data Stream Mining</em></p>
              </ul>
            </li>
          </ul>
          <br/>
        </div>
        <div class="clearer"></div>
        <div><center><a href="#" class="topOfPage">Top</a></center></div>
<?php include('site/includes/bottom.php'); ?>