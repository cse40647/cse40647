<?php include('site/includes/top.php'); ?>
        <div id='blocks' class='block'>
          <div class='block_div block_left'>
            <div id='intro' class='block'><p class="text padding-bottom">Data mining can be viewed as the art of extracting knowledge from large bodies of structured data using methods from many disciplines, including (but not limited to) machine learning, pattern recognition, databases, probability and statistics, information theory, and data visualization. This course will largely place emphasis on the machine learning component, with relevant inclusions and references from other disciplines. The course will give students an opportunity to implement and experiment with some of the concepts, and to also apply them to real-world datasets. Additionally, we will touch upon some of the advances in related fields such as web mining and discuss the role of data mining in contemporary society.</p>
            <p class="text">Altogether, this course will expose students to a wide variety of practical data mining concepts and techniques that are broadly applicable to recommendation, prediction, exploratory data analysis, and business analytics, providing hands-on application of these techniques with <a href="http://xkcd.com/353/" target="_blank">the Python programming language</a>.</p>
            </div>
          </div>
          <div class='block_div block_right'>
            <div id='block_right_text' class='block'>
              <p class="text-header text"><?php echo ucfirst($instructor) ?>:</span>
              <p class="text">
                <a href="http://www.nd.edu/~eaguiar" target="_blank">Everaldo Aguiar</a><br/>
                <a href="http://www.nd.edu/~rjohns15" target="_blank">Reid Johnson</a>
              </p>
              <br/>
              <span class="text-header text">Lectures/Location:</span>
              <p class="text"><?php echo $course_time ?><br/><?php echo $course_loc ?></p>
              <br/>
              <!--<br/><strong>Labs:</strong> F 9:25-10:15am<br/><a href="http://map.nd.edu/#/placemarks/1144/zoom/16/lat/41.69817511364383/lon/-86.23625970632936" target="_blank">DeBartolo Hall 131</a>-->
              <!--<br/><a href="" target="_blank">Dropbox for Submissions</a>-->
              <span class="text-header no-padding">Announcements</span>
              <div id="announcements">
                <ul class="list-small-margin">
                  <li class="item">Great job on the presentations!</li>
                  <li class="item">Assignment 3 out and due 4/04</li>
                  <li class="item">Assignment 2 out and due 3/03</li>
                  <li class="item">Assignment 1 out and due 2/10</li>
                  <li class="item">Assignment 0 out and due 1/22</li>
                  <li class="item">Class starts Wednesday, Jan. 15</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
<?php include('site/includes/bottom.php'); ?>

<!-- You've found hidden data! Let the <?php echo $instructor?> know, and receive 1 point of extra credit for your data mining labors. -->